const express = require('express');
require('dotenv').config();
const cors = require('cors');
const app = express();
app.use(cors()); app.use(express.json());
app.get('/', (req,res)=>res.json({ok:true}));
app.listen(process.env.PORT||4000, ()=>console.log('Server running'));
